/*
	C++ Question 05
	---------------

	Explain the output of the program using comments.
*/

#include <iostream>



class CObject
{
// call init and update on parent class
public:
	virtual void Init() { std::cout << "Calling Object::Init() " << std::endl; }
	virtual void Update() { std::cout << "Calling Object::Update() " << std::endl; }
};


class CActor : public CObject
{
public:
	
	//if function isnt virtual we only get the parents function implementation
	void Init() { std::cout << "Calling Actor::Init() " << std::endl; }

	//if function is virtual we can call this
	virtual void Update() { std::cout << "Calling Actor::Update() " << std::endl; }
};

//obj points to the memory address so we can edit the correct class
void InitAndUpdate(CObject* obj)
{
	if (obj)
	{
		obj->Init();
		obj->Update();
	}
}

int main(int argc, char* argv[])
{
	
	CObject object;
	CActor actor;
	
	//We want to init and update the classes in these memory addresses:
	InitAndUpdate(&object);
	InitAndUpdate(&actor);

	return 0;
}