/*
    C++ Question 06
    ---------------

    Change the definition of class CObject in such a way that child classes NEED TO override 
    the method GetName, so it returns the correct class name.
*/

#include <iostream>
#include <string>

using String = std::string;
using namespace std;

class CObject
{
public:
    virtual String GetName() const { return "Object"; }


};

class CActor : CObject
{

public:
     virtual String GetName() const override { return "actor"; }

};

int main(int argc, char* argv[])
{
    CActor actor;

    std::cout << actor.GetName() << std::endl;
    return 0;
}