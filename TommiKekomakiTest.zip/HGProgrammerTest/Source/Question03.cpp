/*
    C++ Question 03
    ---------------

    You are working on a game. For some reason, enemies in the game are sometimes failing to die although 
    sometimes it works correctly.  You can be sure that the method CEnemy::TakeDamage is properly called 
    with the correct damage.  Find and fix the bug(s).
*/

#include <iostream>

class CEnemy
{
public:
    CEnemy() {}

    void TakeDamage(unsigned int damage)
    {
      if (bIsAlive && health >= 1)
      {
        health -= damage;
      }

	  if (health <= 0)
	  {
		  
          Destroy();
	  }
    }

protected:

    void Destroy()
    {
        bIsAlive = false;
   
    }

private:
public:
    bool bIsAlive = true;
    unsigned int health = 100;
};

int main(int argc, char* argv[])
{
    CEnemy Enemy;

    Enemy.TakeDamage(100);
    if (Enemy.bIsAlive)
    {
        std::cout << Enemy.health;
        std::cout << "Alive";
    }

    else if (!Enemy.bIsAlive)
    {
        std::cout << "Not alive ";
    }

    return 0;
}
