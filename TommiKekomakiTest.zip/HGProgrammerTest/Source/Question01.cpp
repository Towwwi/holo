/*
    C++ Question 01
    ---------------

    Unify the definitions of the two functions into one.
*/

#include <iostream>

#define COUNT_OF(x) (sizeof(x) / sizeof(x[0]))


float GetAverage(int* a, int count, float* b)
{
// 	float sum = 0;
// {
// 		for (int i = 0; i < count; ++i)
// 		{
// 			sum += a[i];
// 
// 		}
// 
// 		return sum / count;

return -1;
	
}

int main(int argc, char* argv[])
{
//     int a[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
//     float b[5] = { 0.0f, 0.1f, 0.2f, 0.3f, 0.4f };
// 
//     float i;
//     std::cout << GetAverage(a, COUNT_OF(a), b) << " " /*<< GetAverage(b, COUNT_OF(b), b) */<< std::endl;
// 
//     return 0;
}