/*
    C++ Question 09
    ---------------

    Write a function WithinMaxAngle that checks if the angle between two arbitrary vectors is less than MAX_DEGREES.
*/

#include <iostream>
#include <cmath>

#define MAX_DEGREES 45.0f
#define RAD_TO_DEG 57.295779513f
# define M_PI   3.14159265358979323846

struct SVector3
{
    float x, y, z;
};


float CalculateDotProduct(const SVector3& v1, const SVector3& v2)
{
	//Can use for-loop too to setup the values
    float dotProduct = v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;

    
	return dotProduct;
}

float CalculateMagnitude(SVector3 a)
{
	return std::sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
}

bool IsWithinMaxAngle(const SVector3& v1, const SVector3& v2)
{

    float dot = CalculateDotProduct(v1,v2);

    float angle = std::acos(dot / (CalculateMagnitude(v1) * CalculateMagnitude(v2)));

    float finalAngle =  (180 / M_PI) * angle;
    std::cout << finalAngle << std::endl;

    if (finalAngle <= MAX_DEGREES)
    {
        return true;
    }

    return false;
}

int main(int argc, char* argv[])
{
    SVector3 a = { 1.0f, 0.0f, 0.0f };
    SVector3 b = { 0.0f, 0.0f, 1.0f };
    SVector3 c = { 9.0f, 0.9f, 0.1f };

    std::cout << std::boolalpha;

    std::cout << IsWithinMaxAngle(a, b) << std::endl;
    std::cout << IsWithinMaxAngle(a, c) << std::endl;

    return 0;
}
