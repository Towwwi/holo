/*
    C++ Question 09
    ---------------

    Write a function WithinMaxAngle that checks if the angle between two arbitrary vectors is less than MAX_DEGREES.
*/

#include <iostream>

#define MAX_DEGREES 45.0f
#define RAD_TO_DEG 57.295779513f

struct SVector3
{
    float x, y, z;
};

bool IsWithinMaxAngle(const SVector3& v1, const SVector3& v2)
{
    return false;
}

int main(int argc, char* argv[])
{
    SVector3 a = { 1.0f, 0.0f, 0.0f };
    SVector3 b = { 0.0f, 0.0f, 1.0f };
    SVector3 c = { 1.0f, 0.2f, 0.1f };

    std::cout << std::boolalpha;
    std::cout << IsWithinMaxAngle(a, b) << std::endl;
    std::cout << IsWithinMaxAngle(a, c) << std::endl;

    return 0;
}