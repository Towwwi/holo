/*
    C++ Question 10
    ---------------

    Given 2 points, a and b, in 3D space, write a function to calculate the rotation parameters 
    (in an axis-angle representation) that will rotate point a in the direction of point b about the origin o.
*/

#include <iostream>

struct SVector3
{
    friend std::ostream& operator<<(std::ostream& output, const SVector3& v)
    {
        output << v.x << ", " << v.y << ", " << v.z;
        return output;
    }

    float x, y, z;
};

class CMath
{
public:
    static void CalculateRotation(const SVector3& o, const SVector3& a, const SVector3& b, SVector3& axis, float& angle)
    {

    }
};

int main(int argc, char* argv[])
{
    SVector3 o = { 2.0f, 2.0f, 2.0f };
    SVector3 a = { 1.0f, 1.0f, 1.0f };
    SVector3 b = { 0.5f, 0.0f, 1.5f };

    SVector3 axis = {};
    float angle = 0.0f;
    CMath::CalculateRotation(o, a, b, axis, angle);
    std::cout << "Axis: " << axis << " angle: " << angle << std::endl;

    return 0;
}