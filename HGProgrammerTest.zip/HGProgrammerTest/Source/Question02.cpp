/*
    C++ Question 02
    ---------------

    Write comments explaining the error(s) in the following code.
    Correct the code so we obtain the expected result.
*/

#include <iostream>

void PrintValuePlus2(int* p)
{
    std::cout << p + 2 << std::endl;
}

int main(int argc, char* argv[])
{
    int value = 40;
    PrintValuePlus2(&value); // Expected result: 42.

    return 0;
}