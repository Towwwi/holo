/*
    C++ Question 03
    ---------------

    You are working on a game. For some reason, enemies in the game are sometimes failing to die although 
    sometimes it works correctly.  You can be sure that the method CEnemy::TakeDamage is properly called 
    with the correct damage.  Find and fix the bug(s).
*/

class CEnemy
{
public:
    CEnemy() {}

    void TakeDamage(unsigned int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Destroy();
        }
    }

protected:
    void Destroy()
    {
        bIsAlive = false;
    }

private:
    bool bIsAlive = true;
    unsigned int health;
};

int main(int argc, char* argv[])
{
    // Game code goes here...

    return 0;
}
